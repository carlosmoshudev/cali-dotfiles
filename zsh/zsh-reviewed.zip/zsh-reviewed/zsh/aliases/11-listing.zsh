# Directory listing presets built only on top of lsd.

alias ls='lsd'
alias l='lsd -l'
alias ll='lsd -lA'
alias la='lsd -A'
alias lla='lsd -lA'
alias l1='lsd -1A'

alias lt='lsd --tree --depth 2'
alias lt1='lsd --tree --depth 1'
alias lt2='lsd --tree --depth 2'
alias lt3='lsd --tree --depth 3'
alias lta='lsd -A --tree --depth 2'

alias lnew='lsd -lA --timesort'
alias lold='lsd -lA --timesort --reverse'
alias lbig='lsd -lA --sizesort'
alias lsmall='lsd -lA --sizesort --reverse'
alias lext='lsd -lA --extensionsort'
alias lver='lsd -lA --versionsort'

alias lgit='lsd -lA --git'
alias lgits='lsd -lA --git --gitsort'

alias lperm='lsd -lA --permission octal'
alias linode='lsd -lA --blocks inode,permission,links,user,group,size,date,name'
alias llinks='lsd -lA --blocks links,permission,user,group,size,date,name'
alias lbytes='lsd -lA --size bytes'
alias ldirsize='lsd -lA --total-size --sizesort'
alias labsdate='lsd -lA --date "+%Y-%m-%d %H:%M:%S"'
alias lplain='lsd -lA --icon never --color never'

_lsd_tree_args() {
  REPLY_DEPTH=2
  REPLY_ROOT=.

  if [[ "${1:-}" == <-> ]]; then
    REPLY_DEPTH="$1"
    shift
  fi

  [[ $# -gt 0 ]] && REPLY_ROOT="$1"
}

lstree() {
  _lsd_tree_args "$@"
  lsd --tree --depth "$REPLY_DEPTH" -- "$REPLY_ROOT"
}

ltd() {
  _lsd_tree_args "$@"
  local version
  version="$(lsd --version 2>/dev/null | awk 'NR == 1 { print $2 }')"

  autoload -Uz is-at-least
  if [[ -n "$version" ]] && is-at-least 1.2.0 "$version"; then
    lsd --tree --directory-only --depth "$REPLY_DEPTH" -- "$REPLY_ROOT"
  elif (( $+commands[tree] )); then
    print -u2 -- "lsd $version does not support --directory-only with --depth; using tree."
    command tree -d -L "$REPLY_DEPTH" -- "$REPLY_ROOT"
  else
    print -u2 -- "lsd $version does not support --directory-only with --depth; using find."
    command find "$REPLY_ROOT" -maxdepth "$REPLY_DEPTH" -type d -print
  fi
}

lstack() {
  local root="${1:-${STACKS_DIR:-/srv/containers/pro}}"
  lsd -lA --tree --depth 2 -- "$root"
}

lmedia() {
  local root="${1:-${MEDIA:-/srv/media}}"
  lsd -lA -- "$root"
}

llogs() {
  local root="${1:-/var/log}"
  lsd -lA --timesort --date relative -- "$root"
}

lcompose() {
  local root="${1:-${STACKS_DIR:-/srv/containers/pro}}"

  find "$root" -maxdepth 4 -type f \
    \( -name compose.yml \
       -o -name compose.yaml \
       -o -name docker-compose.yml \
       -o -name docker-compose.yaml \) \
    -print0 2>/dev/null |
    xargs -0 -r lsd -l --date relative --
}

lbroken() {
  local root="${1:-.}"
  find "$root" -xdev -xtype l -print0 2>/dev/null |
    xargs -0 -r lsd -ld --
}

lempty() {
  local root="${1:-.}"
  find "$root" -xdev -empty -print0 2>/dev/null |
    xargs -0 -r lsd -ld --date relative --
}

lchanged() {
  local days=1
  local root=.

  if [[ "${1:-}" == <-> ]]; then
    days="$1"
    shift
  fi
  [[ $# -gt 0 ]] && root="$1"

  find "$root" -xdev -type f -mtime "-$days" -print0 2>/dev/null |
    xargs -0 -r lsd -ld --timesort --date relative --
}

lworld() {
  local root="${1:-.}"
  find "$root" -xdev \( -type f -o -type d \) -perm -0002 -print0 2>/dev/null |
    xargs -0 -r lsd -ld --permission octal --
}
