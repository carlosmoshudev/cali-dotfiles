# Universal interactive-shell helpers.

if (( $+commands[batcat] )); then
  alias cat='batcat --paging=never --style=plain'
  alias bat='batcat'
elif (( $+commands[bat] )); then
  alias cat='bat --paging=never --style=plain'
else
  alias cat='/bin/cat'
fi

alias tcat='/bin/cat'
alias grep='grep --color=auto'
alias cls='clear'
alias reload='source "$HOME/.zshrc"'
alias moshu-ipscan="$HOME/scripts/moshu-ipscan"

# The Oh My Zsh sudo plugin already supports prefixing the current command
# with sudo (press Esc twice). A history-reexecution alias is intentionally
# avoided because it does not preserve every command safely.
