# Docker and Docker Compose helpers.

alias dps='docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"'
alias dcps='docker compose ps'
alias dcu='docker compose up -d'
alias docker-up='docker compose up -d'
alias dcd='docker compose down'
alias docker-down='docker compose down'
alias dcl='docker compose logs -f --tail=200'
alias dlogs='docker compose logs -f --tail=200'
alias docker-logs='docker compose logs -f --tail=200'
alias dexec='docker compose exec'
alias docker-exec='docker compose exec'
alias ddf='docker system df -v'
alias dtop='docker stats --no-stream'

dcrestart() {
  docker compose restart "$@"
}
alias docker-restart='dcrestart'

# Pull first to avoid needless downtime. Do not run `docker image prune -a`
# automatically: that removes every unused image on the host, including useful
# rollback images from unrelated stacks.
dcupgrade() {
  docker compose pull "$@" &&
    docker compose up -d --remove-orphans "$@"
}
alias docker-upgrade='dcupgrade'

# Conservative cleanup; dangling images only.
dprune() {
  docker image prune -f
}
