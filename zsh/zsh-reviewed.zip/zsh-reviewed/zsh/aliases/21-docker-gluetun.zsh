# Gluetun forwarded-port helper.

ffport() {
  local container="${GLUETUN_CONTAINER:-gluetun}"
  local port

  port="$(docker exec "$container" cat /tmp/gluetun/forwarded_port 2>/dev/null)" || {
    print -u2 -- "Could not read the forwarded port from container: $container"
    return 1
  }

  [[ -n "$port" ]] || {
    print -u2 -- "Gluetun has not published a forwarded port yet."
    return 1
  }

  print -r -- "$port"
}
