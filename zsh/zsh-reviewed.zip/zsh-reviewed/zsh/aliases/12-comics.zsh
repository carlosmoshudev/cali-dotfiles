# Optional comics workspace helpers.

_comics_workspace=""
_alias_source=${(%):-%N}
_alias_dir=${_alias_source:A:h}
_alias_root=${_alias_dir:A:h}

if [[ -n ${COMICS_WORKSPACE:-} && -d "$COMICS_WORKSPACE/tools" ]]; then
  _comics_workspace="$COMICS_WORKSPACE"
elif [[ -n ${COMICS_ROOT:-} && -d "$COMICS_ROOT/tools" ]]; then
  _comics_workspace="$COMICS_ROOT"
elif [[ -d /srv/media/comics/tools ]]; then
  _comics_workspace=/srv/media/comics
elif [[ -d "$_alias_root/tools" ]]; then
  _comics_workspace="$_alias_root"
elif [[ -d "$_alias_root/../tools" ]]; then
  _comics_workspace=${_alias_root:A:h}
fi

if [[ -n "$_comics_workspace" ]]; then
  export COMICS_WORKSPACE="$_comics_workspace"
  export COMICS_TOOLS_DIR="$COMICS_WORKSPACE/tools"

  _comic_tool() {
    local script="$1"
    shift

    if [[ ! -f "$COMICS_TOOLS_DIR/$script" ]]; then
      print -u2 -- "Comic tool not found: $COMICS_TOOLS_DIR/$script"
      return 127
    fi

    bash "$COMICS_TOOLS_DIR/$script" "$@"
  }

  cbr_inspect()  { _comic_tool cbr_inspect.sh "$@"; }
  cbr_export()   { _comic_tool cbr_export.sh "$@"; }
  cbr_fake()     { _comic_tool cbr_fake.sh "$@"; }
  cbz_verify()   { _comic_tool cbz_verify.sh "$@"; }
  cbz_pack()     { _comic_tool cbz_pack.sh "$@"; }
  cbz_pack_all() { _comic_tool cbz_pack_all.sh "$@"; }
  cbz_flatten()  { _comic_tool cbz_flatten.sh "$@"; }
fi

unset _comics_workspace _alias_source _alias_dir _alias_root
