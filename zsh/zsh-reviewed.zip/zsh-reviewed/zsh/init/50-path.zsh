# Zsh keeps $path and $PATH synchronized. -U removes duplicate entries.
typeset -U path PATH

[[ -d "$HOME/.opencode/bin" ]] && path=("$HOME/.opencode/bin" $path)
[[ -d "$HOME/.local/bin" ]] && path=("$HOME/.local/bin" $path)

export PATH
