setopt autocd
setopt correct
setopt interactive_comments
setopt auto_pushd
setopt pushd_ignore_dups
setopt pushd_silent

HISTSIZE=50000
SAVEHIST=50000
HISTFILE="$HOME/.zsh_history"

setopt extended_history
setopt share_history
setopt hist_expire_dups_first
setopt hist_find_no_dups
setopt hist_ignore_all_dups
setopt hist_reduce_blanks
setopt hist_save_no_dups
