# Clear aliases that this configuration owns. This is mainly useful when
# reloading ~/.zshrc in an already-running shell.
unalias cat bat grep ls l ll la lla l1 lt lt1 lt2 lt3 lta \
  lnew lold lbig lsmall lext lver lgit lgits lperm linode llinks lbytes \
  ldirsize labsdate lplain df du dfh cls reload \
  .. ... .... ..... composefiles srv server comics home media \
  update upgradable ports myip weather moshu-ipscan tcat \
  dps dcps dcu dcd dcl dlogs dexec ddf dtop \
  docker-up docker-down docker-restart docker-logs docker-exec docker-upgrade \
  jerr jf ffport 2>/dev/null
