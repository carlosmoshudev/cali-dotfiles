[[ -r "$HOME/.dotfiles/zsh/.zshrc_aliases" ]] && \
  source "$HOME/.dotfiles/zsh/.zshrc_aliases"
