export ZSH="$HOME/.oh-my-zsh"
ZSH_THEME="powerlevel10k/powerlevel10k"

plugins=(
  git
  sudo
  z
  fzf
  docker
  zsh-history-substring-search
  zsh-autosuggestions
  colored-man-pages
  extract
  command-not-found
  ssh-agent
  systemd
  zsh-interactive-cd
  zsh-syntax-highlighting
)

if [[ -r "$ZSH/oh-my-zsh.sh" ]]; then
  source "$ZSH/oh-my-zsh.sh"
else
  print -u2 -- "Warning: Oh My Zsh not found at $ZSH"
fi

[[ -r "$HOME/.p10k.zsh" ]] && source "$HOME/.p10k.zsh"
