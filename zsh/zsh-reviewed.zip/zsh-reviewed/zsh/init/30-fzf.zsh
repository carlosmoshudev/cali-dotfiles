# Preserve options inherited from the environment or another plugin.
export FZF_DEFAULT_OPTS="${FZF_DEFAULT_OPTS:+$FZF_DEFAULT_OPTS }--height 40% --layout=reverse --border"
