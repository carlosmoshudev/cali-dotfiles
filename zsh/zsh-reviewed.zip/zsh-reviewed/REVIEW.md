# Zsh configuration review

This is a conservative revised copy of the uploaded configuration. It is not
installed automatically.

Main changes:

- Removed the duplicated `sudo` Oh My Zsh plugin.
- Replaced hard-coded `/home/gari` entries with `$HOME` and deduplicated `$PATH`.
- Fixed `apt-get list --upgradable` to `apt list --upgradable`.
- Converted commands that contain pipes or multi-command workflows into
  functions so arguments go to the intended command.
- Kept `11-listing.zsh` limited to `lsd` functionality.
- Added an `ltd` fallback for `lsd` versions older than 1.2.0.
- Removed duplicate Docker aliases and standardized log tails at 200 lines.
- Replaced destructive Docker upgrade logic. Upgrades no longer stop the stack
  before pulling and no longer run global `docker image prune -a -f`.
- Removed unnecessary TTY allocation from the Gluetun forwarded-port helper.
- Scoped loader variables to avoid leaking names into the interactive shell.
- Added file-existence checks for individual comics tools.

Review the diff before copying anything into `~/.dotfiles`.
